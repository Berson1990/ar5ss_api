<?php

namespace App\Http\Controllers;

use App\Http\Models\HotAdds;
use App\Http\Models\SliderChangeMode;
use Illuminate\Auth\Access\Response;
use Illuminate\Http\Request;
use phpDocumentor\Reflection\DocBlock\Tags\Return_;

class HotAdsController extends Controller
{
    //
    public function __construct()
    {
        $this->hotadss = new HotAdds();
    }

    public function GetHotAds()
    {
        $output = $this->hotadss->get();
        $Mode = SliderChangeMode::all();
        return Response()->json([
                "Slider" => $output,
                "Mode" => $Mode,
            ]);
    }
}
