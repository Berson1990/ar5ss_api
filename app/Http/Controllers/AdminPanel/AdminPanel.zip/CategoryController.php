<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;

use Illuminate\Auth\Access\Response;
use Illuminate\Http\Request;
use App\Http\Models\Category;
use DB;
class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $output=Category::get();
        return Response()->json($output);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = Request()->all();
        $baseurl = 'http://ar5ss.com/ar5ss/public/';
        $output = Category::create($input);
        $id = $output['CategoryID'];
        $image = $input["CategoryIamge"];
        $jpg_name = "photo-" . $id . ".jpg";
        $path = public_path("/CategoryImage/") . $jpg_name;
        $input["Image"] = $baseurl . "CategoryImage/" . $jpg_name;
        $img = substr($image, strpos($image, ",") + 1);//take string after ,
        $imgdata = base64_decode($img);
        $success = file_put_contents($path, $imgdata);
        $output = Category::find($id)->update($input);
        $output = Category::where('CategoryID','=',$id)->get();
        return Response()->json($output);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = Request()->all();
        if ($input['CategoryImage'] == '') {
            $output = Category::find($id)->update([
                "categroy_name" => $input["categroy_name"],
                "categroy_nameen" => $input["categroy_nameen"],
            ]);
            $output = Category::where('CategoryID', '=', $id)->get();
            return Response()->json($output);

        } else {
            $baseurl = 'http://ar5ss.com/ar5ss/public/';
            $image = $input["CategoryImage"];
            $jpg_name = "photo-" . $id . ".jpg";
            $path = public_path("/CategoryImage/") . $jpg_name;
            $input["Image"] = $baseurl . "CategoryImage/" . $jpg_name;
            $img = substr($image, strpos($image, ",") + 1);//take string after ,
            $imgdata = base64_decode($img);
            $success = file_put_contents($path, $imgdata);
            $output = Category::find($id)->update($input);
            $output = Category::where('CategoryID', '=', $id)->get();
            return Response()->json($output);

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
