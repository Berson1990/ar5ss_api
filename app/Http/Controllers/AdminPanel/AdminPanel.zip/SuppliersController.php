<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use App\Http\Models\Users;


class SuppliersController extends Controller
{
    public function __construct()
    {
        $this->users = new Users();
    }

    public function getSuppliers()
    {
        $output = $this->users
            ->where($this->users->getTable() . '.UseType', '=', 3)
            ->where($this->users->getTable() . '.UseType', '!=', 1)
            ->get();
        return Response()->json($output);
    }

    public function createNewSuppliers()
    {

        $input = Request()->all();
        $Email = $input['Email'];
        $check = $this->users->where('Email', '=', $Email)->get();
        if (Count($check) > 0) {
            $output = ['Erorr' => 'This Email is Exist'];
        } else {
            $input['Password'] = MD5($input['Password']);
            $input['UseType'] = 3;
            $output = $this->users->create($input);
        }
        return Response()->json($output);
    }

    public function updateSuppliers($id)
    {
        $baseurl = 'http://ar5ss.com/ar5ss/public/';
        $input = Request()->all();
        if ($input['Image'] == '') {
            $output = Users::find($id)->update([
                "Name" => $input["Name"],
                "Email" => $input["Email"],
                "Mobile" => $input["Mobile"],
            ]);
            $output = Users::where('UserID', '=', $id)->get();
            return Response()->json($output['0']);

        } else {
            $image = $input["Image"];
            $jpg_name = "photo-" . time() . ".jpg";
            $path = public_path("/UserImages/") . $jpg_name;
            $input["Image"] = $baseurl . "UserImages/" . $jpg_name;
            $img = substr($image, strpos($image, ",") + 1);//take string after ,
            $imgdata = base64_decode($img);
            $success = file_put_contents($path, $imgdata);
            $output = Users::find($id)->update($input);
            $output = Users::where('UserID', '=', $id)->get();
            return Response()->json($output['0']);

        }

    }

    public function stopSuppliers($id)
    {
        $input = Request()->all();
        $UserState = $input['UserState'];
        if ($UserState == 1) {
            $UserState = 0;
        } else {
            $UserState = 1;
        }
        $output = $this->users->where($this->users->getTable() . '.UserID', '=', $id)
            ->update(['UserState' => $UserState]);
        $output = $this->users->where($this->users->getTable() . '.UserID', '=', $id)
            ->get();

        return Response()->json($output);
    }

    public function SgininAdmin()
    {
        $input = Request()->all();
        $input['Password'] = MD5($input['Password']);
        $output = $this->users
            ->where($this->users->getTable() . '.Email', '=', $input['Email'])
            ->where($this->users->getTable() . '.Password', '=', $input['Password'])
            ->where($this->users->getTable() . '.UseType', '=', 1)
            ->get();

        if (count($output) > 0) {

            return ["error" => "invalid Account"];
        } else {

            return ["success" => "valid Account"];
        }
    }
}
