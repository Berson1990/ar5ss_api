<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use App\Http\Models\Brand;
use App\Http\Models\Category;
use App\Http\Models\Color;
use App\Http\Models\Product;
use App\Http\Models\ProductColor;
use App\Http\Models\ProductImage;
use App\Http\Models\ProductPrice;
use App\Http\Models\Size;
use Illuminate\Http\Request;

class AdminProductController extends Controller
{
    public function __construct()
    {
        $this->product = new Product();
        $this->category = new Category();
        $this->brand = new Brand();
        $this->size = new Size();
        $this->productprice = new ProductPrice();
        $this->productcolor = new ProductColor();
        $this->productImage = new ProductImage();
        $this->color = new Color();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $output = $this->product
            ->leftjoin($this->productprice->getTable(), $this->product->getTable() . '.ProductID', '=', $this->productprice->getTable() . '.ProductID')
            ->leftjoin($this->productcolor->getTable(), $this->product->getTable() . '.ProductID', '=', $this->productcolor->getTable() . '.ProductID')
            ->leftjoin($this->color->getTable(), $this->productcolor->getTable() . '.ColorID', '=', $this->color->getTable() . '.ColorID')
            ->leftjoin($this->productImage->getTable(), $this->productcolor->getTable() . '.ProductColorID', '=', $this->productImage->getTable() . '.ProductColorID')
            ->leftjoin($this->size->getTable(), $this->product->getTable() . '.SizeID', '=', $this->size->getTable() . '.SizeID')
            ->leftjoin($this->category->getTable(), $this->product->getTable() . '.CategoryID', '=', $this->category->getTable() . '.CategoryID')
            ->leftjoin($this->brand->getTable(), $this->product->getTable() . '.BrandID', '=', $this->brand->getTable() . '.BrandID')
            ->groupby($this->product->getTable() . '.ProductID')
            ->get();
        return Response()->json($output);
    }

    public function getProductImage($id)
    {
        $outupt = $this->productcolor->with('ProductImage', 'ColorsOfProduct')
            ->where($this->productcolor->getTable() . '.ProductID', '=', $id)
            ->get();
        return Response()->json($outupt);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = Request()->all();
        $output = $this->product->create($input);
        $ProductID = $output['ProductID'];
        $output = $this->productprice->create([
            "ProductID" => $ProductID,
            "ProductPrice" => $input["ProductPrice"]
        ]);

        $output = $this->product
            ->leftjoin($this->productprice->getTable(), $this->product->getTable() . '.ProductID', '=', $this->productprice->getTable() . '.ProductID')
            ->leftjoin($this->productcolor->getTable(), $this->product->getTable() . '.ProductID', '=', $this->productcolor->getTable() . '.ProductID')
            ->leftjoin($this->color->getTable(), $this->productcolor->getTable() . '.ColorID', '=', $this->color->getTable() . '.ColorID')
            ->leftjoin($this->productImage->getTable(), $this->productcolor->getTable() . '.ProductColorID', '=', $this->productImage->getTable() . '.ProductColorID')
            ->leftjoin($this->size->getTable(), $this->product->getTable() . '.SizeID', '=', $this->size->getTable() . '.SizeID')
            ->leftjoin($this->category->getTable(), $this->product->getTable() . '.CategoryID', '=', $this->category->getTable() . '.CategoryID')
            ->leftjoin($this->brand->getTable(), $this->product->getTable() . '.BrandID', '=', $this->brand->getTable() . '.BrandID')
            ->where($this->product->getTable() . '.ProductID', '=', $ProductID)
            ->groupby($this->product->getTable() . '.ProductID')
            ->get();
        return Response()->json($output);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function InsertImage(){
        $input =Request()->all();
        $output = $this->productcolor->create($input);
        $input['ProductColorID'] = $output['ProductColorID'];
        $output = $this->productImage->create($input);
        $outupt = $this->productcolor->with('ProductImage', 'ColorsOfProduct')
            ->where($this->productcolor->getTable() . '.ProductID', '=', $input['ProductID'])
            ->get();
        return Response()->json($outupt);
    }
}
